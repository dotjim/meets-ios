//
//  MGMeetsProduct.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 21/10/13.
//  Original work Copyright (c) 2013 TheAgileMonkeys.
//

#import "MeetsProduct.h"

@interface MGMeetsProduct : MeetsProduct

@end
