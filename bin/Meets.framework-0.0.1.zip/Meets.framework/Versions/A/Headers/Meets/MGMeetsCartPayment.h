//
//  MGMeetsCartPayment.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 28/11/13.
//  Original work Copyright (c) 2013 TheAgileMonkeys.
//

#import "MeetsCartPayment.h"

@interface MGMeetsCartPayment : MeetsCartPayment

@end
