//
//  MGCatalogCategoryTree.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 11/11/13.
//  Original work Copyright (c) 2013 TheAgileMonkeys.
//

#import "MGCatalogCategory.h"

@interface MGCatalogCategoryTree : MGCatalogCategory

@end
