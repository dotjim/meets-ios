//
//  MGCustomerCustomerUpdate.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 27/01/14.
//  Original work Copyright (c) 2014 TheAgileMonkeys.
//

#import "SoapApiMethod.h"

@interface MGCustomerCustomerUpdate : SoapApiMethod

@end
