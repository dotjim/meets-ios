//
//  MGMeetsCollection.h
//  Aristocrazy
//
//  Created by Juan Fernández Sagasti on 12/11/13.
//  Original work Copyright (c) 2013 TheAgileMonkeys.
//

#import <Foundation/Foundation.h>

@interface MGMeetsCollection : MeetsCollection

@end
