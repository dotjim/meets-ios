//
//  MGCatalogInventoryStockItemList.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 31/12/13.
//  Original work Copyright (c) 2013 TheAgileMonkeys.
//

#import "SoapApiMethod.h"

@interface MGCatalogInventoryStockItemList : SoapApiMethod

@end
