//
//  MGMeetsStockItem.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 16/01/14.
//  Original work Copyright (c) 2014 TheAgileMonkeys.
//

#import "MeetsStockItem.h"

@interface MGMeetsStockItem : MeetsStockItem

@end
