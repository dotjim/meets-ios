//
//  MGMeetsStockItemList.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 15/01/14.
//  Original work Copyright (c) 2014 TheAgileMonkeys.
//

#import "MeetsStockItemList.h"

@interface MGMeetsStockItemList : MeetsStockItemList

@end
