//
//  MGCatalogCategoryTree.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 05/11/13.
//  Original work Copyright (c) 2013 TheAgileMonkeys.
//

#import "MGCatalogCategory.h"

@interface MGCatalogCategoryLevel : MGCatalogCategory

@end
