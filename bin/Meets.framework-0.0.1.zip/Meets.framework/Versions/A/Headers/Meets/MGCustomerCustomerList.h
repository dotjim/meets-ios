//
//  MGCustomerCustomerList.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 20/12/13.
//  Original work Copyright (c) 2013 TheAgileMonkeys.
//

#import "SoapApiMethod.h"

@interface MGCustomerCustomerList : SoapApiMethod

@end
