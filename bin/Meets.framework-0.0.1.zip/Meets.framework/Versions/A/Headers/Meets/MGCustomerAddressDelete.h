//
//  MGCustomerAddressDelete.h
//  iOS Meets SDK
//
//  Created by Juan Fernández Sagasti on 10/02/14.
//  Original work Copyright (c) 2014 TheAgileMonkeys.
//

#import "SoapApiMethod.h"

@interface MGCustomerAddressDelete : SoapApiMethod

@end
